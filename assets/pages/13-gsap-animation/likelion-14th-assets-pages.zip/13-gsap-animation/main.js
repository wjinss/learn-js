{

  // Web Animations API
  function playground() {

  }

  // GSAP API
  function playgroundGSAP() {
    
  }

  setTimeout(() => {
    playgroundGSAP()
    playground()
  }, 500)
}
